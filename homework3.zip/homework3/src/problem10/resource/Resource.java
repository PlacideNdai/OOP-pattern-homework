package problem5.resource;

import java.io.InputStream;

public interface Resource {
    InputStream getResourceAsStream();
}
