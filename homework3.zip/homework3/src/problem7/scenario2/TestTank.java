package problem1.scenario2;
// I have already imported Tank class from Tank.jar
import com.bing.tank.Tank;

public class TestTank {
    public static void main(String[] args) {
        // record move() execution time of a tank
    }
}
