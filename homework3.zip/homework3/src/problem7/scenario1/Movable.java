package problem1.scenario1;

interface Movable {
    void move();
}