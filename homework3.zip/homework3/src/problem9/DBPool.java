package problem2;

import java.sql.Connection;
import java.util.LinkedList;

public class DBPool {
    // Container for storing DB connections

    public DBPool(int initialSize) {

    }

    public Connection fetchConn() {
        return null;
    }

    public void releaseConn(Connection conn) {

    }
}
